var _settings_save_game_8h =
[
    [ "USettingsSaveGame", "class_u_settings_save_game.html", "class_u_settings_save_game" ]
];