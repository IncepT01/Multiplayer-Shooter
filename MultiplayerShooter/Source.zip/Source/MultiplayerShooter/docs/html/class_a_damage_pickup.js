var class_a_damage_pickup =
[
    [ "OnSphereOverlap", "class_a_damage_pickup.html#ab977e9731322c529a542706384ea3d3a", null ],
    [ "BaseDamageBuff", "class_a_damage_pickup.html#a11d2f90fb1f4563ea046bde2d9415484", null ],
    [ "DamageBuffTime", "class_a_damage_pickup.html#ab917285ac63f6caf696a71002a4ac998", null ],
    [ "Name", "class_a_damage_pickup.html#a1d2c7a3340e68add38c4d1c0f21dcde8", null ]
];