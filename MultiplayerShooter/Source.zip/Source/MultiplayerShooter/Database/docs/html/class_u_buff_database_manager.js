var class_u_buff_database_manager =
[
    [ "Get", "class_u_buff_database_manager.html#ae866f9a543fc1382dfa84a64cc7e8384", null ],
    [ "LoadBuffs", "class_u_buff_database_manager.html#abe0d0f39929b126a6f911df6b1555228", null ],
    [ "Database", "class_u_buff_database_manager.html#aea9f48d29b9c6a5162758bfe27729899", null ],
    [ "Instance", "class_u_buff_database_manager.html#aec44515f910fa2f671a402e4d83b2eec", null ]
];