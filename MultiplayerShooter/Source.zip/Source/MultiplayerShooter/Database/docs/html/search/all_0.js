var searchData=
[
  ['buffdatabasemanager_2ecpp_0',['BuffDatabaseManager.cpp',['../_buff_database_manager_8cpp.html',1,'']]],
  ['buffdatabasemanager_2eh_1',['BuffDatabaseManager.h',['../_buff_database_manager_8h.html',1,'']]]
];
