var searchData=
[
  ['instance_0',['Instance',['../class_u_buff_database_manager.html#aec44515f910fa2f671a402e4d83b2eec',1,'UBuffDatabaseManager']]]
];
