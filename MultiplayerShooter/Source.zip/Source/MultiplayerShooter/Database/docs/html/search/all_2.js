var searchData=
[
  ['get_0',['Get',['../class_u_buff_database_manager.html#ae866f9a543fc1382dfa84a64cc7e8384',1,'UBuffDatabaseManager']]]
];
