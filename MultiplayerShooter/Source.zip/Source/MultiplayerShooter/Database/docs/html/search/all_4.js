var searchData=
[
  ['loadbuffs_0',['LoadBuffs',['../class_u_buff_database_manager.html#abe0d0f39929b126a6f911df6b1555228',1,'UBuffDatabaseManager']]]
];
