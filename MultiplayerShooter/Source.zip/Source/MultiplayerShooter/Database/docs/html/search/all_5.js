var searchData=
[
  ['ubuffdatabasemanager_0',['UBuffDatabaseManager',['../class_u_buff_database_manager.html',1,'']]]
];
