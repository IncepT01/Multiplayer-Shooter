var files_dup =
[
    [ "BuffDatabaseManager.cpp", "_buff_database_manager_8cpp.html", null ],
    [ "BuffDatabaseManager.h", "_buff_database_manager_8h.html", "_buff_database_manager_8h" ]
];