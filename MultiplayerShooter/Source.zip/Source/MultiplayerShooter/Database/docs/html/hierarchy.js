var hierarchy =
[
    [ "UObject", null, [
      [ "UBuffDatabaseManager", "class_u_buff_database_manager.html", null ]
    ] ]
];