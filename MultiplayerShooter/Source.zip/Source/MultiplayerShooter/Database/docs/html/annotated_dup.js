var annotated_dup =
[
    [ "UBuffDatabaseManager", "class_u_buff_database_manager.html", "class_u_buff_database_manager" ]
];