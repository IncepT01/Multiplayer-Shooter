var searchData=
[
  ['hitboxinfo_0',['HitBoxInfo',['../struct_f_frame_package.html#ad4e9b0e902a7f049556afbbadf365ce4',1,'FFramePackage']]]
];
