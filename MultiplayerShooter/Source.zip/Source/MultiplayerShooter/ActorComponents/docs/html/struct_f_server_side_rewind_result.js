var struct_f_server_side_rewind_result =
[
    [ "bHeadShot", "struct_f_server_side_rewind_result.html#a9e4239d27d8156645a2413c876ed5ebf", null ],
    [ "bHitConfirmed", "struct_f_server_side_rewind_result.html#a145b900f5215ea63559cfdf64446595b", null ]
];