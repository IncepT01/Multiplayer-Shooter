var struct_f_frame_package =
[
    [ "Character", "struct_f_frame_package.html#a9ed963b521d8f09db397b434a60596dc", null ],
    [ "HitBoxInfo", "struct_f_frame_package.html#ad4e9b0e902a7f049556afbbadf365ce4", null ],
    [ "Time", "struct_f_frame_package.html#aad0c47aaadea4cd35f4eb7ee1949bc64", null ]
];