var struct_f_box_information =
[
    [ "BoxExtent", "struct_f_box_information.html#af05792261ffca7a4e3641f5114e71bdb", null ],
    [ "Location", "struct_f_box_information.html#acb668b622741fd3656c5faf12f7fee33", null ],
    [ "Rotation", "struct_f_box_information.html#a16408bba83bc1cc3e37407814bc0d6ef", null ]
];