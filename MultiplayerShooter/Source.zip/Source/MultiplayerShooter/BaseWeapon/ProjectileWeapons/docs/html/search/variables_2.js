var searchData=
[
  ['damage_0',['Damage',['../class_a_projectile.html#ae97caea3145d36d3a59a9e9c19a45a85',1,'AProjectile']]]
];
