var hierarchy =
[
    [ "AActor", null, [
      [ "AProjectile", "class_a_projectile.html", [
        [ "AProjectileBullet", "class_a_projectile_bullet.html", null ]
      ] ]
    ] ],
    [ "ABaseWeapon", null, [
      [ "AProjectileWeapon", "class_a_projectile_weapon.html", null ]
    ] ]
];