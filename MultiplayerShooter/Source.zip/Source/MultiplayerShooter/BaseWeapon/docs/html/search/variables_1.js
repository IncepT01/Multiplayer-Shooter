var searchData=
[
  ['bautomatic_0',['bAutomatic',['../class_a_base_weapon.html#a363003e83b0e92395f3daed4325280b3',1,'ABaseWeapon']]],
  ['buseserversiderewind_1',['bUseServerSideRewind',['../class_a_base_weapon.html#ad61f925621157187d778573e91790170',1,'ABaseWeapon::bUseServerSideRewind'],['../class_a_projectile.html#a2545db2507877b34ea42d6382fa598c9',1,'AProjectile::bUseServerSideRewind']]]
];
