var annotated_dup =
[
    [ "ABaseWeapon", "class_a_base_weapon.html", "class_a_base_weapon" ],
    [ "AProjectile", "class_a_projectile.html", "class_a_projectile" ],
    [ "AProjectileBullet", "class_a_projectile_bullet.html", "class_a_projectile_bullet" ],
    [ "AProjectileWeapon", "class_a_projectile_weapon.html", "class_a_projectile_weapon" ]
];