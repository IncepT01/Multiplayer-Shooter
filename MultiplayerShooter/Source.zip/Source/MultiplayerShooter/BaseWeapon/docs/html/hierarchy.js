var hierarchy =
[
    [ "AActor", null, [
      [ "ABaseWeapon", "class_a_base_weapon.html", [
        [ "AProjectileWeapon", "class_a_projectile_weapon.html", null ]
      ] ],
      [ "AProjectile", "class_a_projectile.html", [
        [ "AProjectileBullet", "class_a_projectile_bullet.html", null ]
      ] ]
    ] ]
];